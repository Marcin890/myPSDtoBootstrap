import "bootstrap/dist/js/bootstrap";
import $ from "jquery";
import "./sass/index.scss";
import "./js/scroll";
